package local.htss.apgo.lib;

public class BuildProperties {
    public static final boolean DEBUG_MODE = true;
}
