package local.htss.apgo.net.protocol.shared;

public interface SupportCodec {
}
